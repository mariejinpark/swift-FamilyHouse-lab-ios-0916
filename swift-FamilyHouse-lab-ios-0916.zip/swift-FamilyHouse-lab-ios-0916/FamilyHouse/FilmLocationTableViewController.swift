//
//  TableViewController.swift
//  FamilyHouse
//
//  Created by Marie Park on 10/10/16.
//  Copyright © 2016 Flatiron School. All rights reserved.
//

import Foundation
import UIKit

class FilmLocationTableViewController: UITableViewController {

    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var tvseriesLabel: UILabel!
    
    var filmLocation: FilmLocation! {
        func didSet(){
            addressLabel.text = filmLocation.address
            nameLabel.text = filmLocation.name
            tvseriesLabel.text = String(describing: filmLocation.tvSeries)
        }
    }
    
}


